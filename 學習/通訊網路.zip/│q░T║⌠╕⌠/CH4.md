- 光纖接頭
	ST-10BaseF
	SC
	LC-路由器
 ^acd46a
- 網路卡
	[[OSI 模型#資料鏈結層]]
	AUI---AUI纜線
	BNC---RG-58
	RJ-45---UTP/STP
	
	類型
	1. ISA--NOPE
	2. PCI--NOPE
	3. PCIe--server
	4. USB--PC
	
	介面
	1. RJ-45(電)
		只能在500MHz以下頻寬用
	2. SC, LC

閘道器能在不同協定間移動資料，而路由器則是在不同網路間移動資料