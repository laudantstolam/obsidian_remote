#### NetID HostID
舉個例子來說明：考慮一個IPv4地址，如192.168.1.100，其中192.168.1是NetID，而100是HostID。這意味著這個IP地址位於網絡192.168.1上，而100是該網絡上的某個特定設備的標識符。
#### IP分類
![image.png|625](https://raw.githubusercontent.com/Ash0645/image_remote/main/202310042259285.png)
#### 網路遮罩
把IP跟遮罩做二進制AND運算得到NetID=網路位址=網段
#### 特例

